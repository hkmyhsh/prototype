# Codex Agent Harness Example

This repository is a scaffold for using Codex with a lightweight agent harness and repository-local Memory Store.

Theme:

> Detect GitHub Actions jobs waiting for self-hosted runners for 20 minutes or longer and notify operators.

## Files

- `AGENTS.md`: Codex working rules and agent roles.
- `.agent/task.md`: Task definition.
- `.agent/state.json`: Machine-readable task state.
- `.agent/plan.md`: Planner output.
- `.agent/decisions.md`: Decision log.
- `.agent/review.md`: Reviewer notes.
- `.agent/project_rules.md`: Project rules.
- `.agent/prompts/`: Role-specific prompts.
- `docs/design.md`: Initial design.
- `docs/runbook.md`: Initial runbook.

## How to use with Codex

1. Open the repository with Codex.
2. Ask Codex to read `AGENTS.md`.
3. Start with Planner mode:

```text
Use Planner mode. Read AGENTS.md and .agent/*.md, then refine the plan for the GitHub Actions self-hosted runner waiting-job detector.
```

4. Continue with Executor mode:

```text
Use Executor mode. Execute the current next_action in .agent/state.json and update the Memory Store.
```

5. Finish with Reviewer mode:

```text
Use Reviewer mode. Review the design, runbook, and Memory Store. Update .agent/review.md and .agent/state.json.
```
