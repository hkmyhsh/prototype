# Plan

## Objective

Design a practical first version of a GitHub Actions self-hosted runner waiting-job detector.

## Work breakdown

### Step 1: Baseline design

Create `docs/design.md` covering:

- Problem statement.
- Target users.
- Architecture.
- GitHub API access.
- Wait-time calculation.
- Notification flow.
- Failure handling.
- Audit/logging.
- Security considerations.

### Step 2: Data model

Define the minimal records needed for detection:

- Repository or organization target.
- Workflow run ID.
- Job ID.
- Job name.
- Labels.
- Status.
- Created timestamp.
- Started timestamp if available.
- Waiting duration.
- Notification status.

### Step 3: Detection logic

Define algorithm:

1. List recent workflow runs or jobs.
2. Filter jobs that are queued or waiting for self-hosted runner capacity.
3. Calculate waiting duration.
4. Compare with threshold.
5. Suppress duplicate notifications.
6. Notify operators.
7. Log result.

### Step 4: Security design

Define:

- GitHub App permissions.
- Secret storage.
- AWS IAM permissions.
- Network access.
- Notification endpoint protection.
- Audit log requirements.

### Step 5: Runbook

Create `docs/runbook.md` covering:

- Alert meaning.
- Initial triage.
- Common causes.
- Escalation.
- Recovery actions.
- Post-incident update.

### Step 6: Review

Use Reviewer mode to check:

- Correctness.
- Operability.
- Security.
- Maintainability.
- Gaps and assumptions.

## Completion criteria

- `docs/design.md` exists.
- `docs/runbook.md` exists.
- `.agent/decisions.md` is updated.
- `.agent/review.md` has reviewer findings.
- `.agent/state.json` accurately reflects current status.
