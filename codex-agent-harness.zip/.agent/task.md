# Task

## Theme

GitHub Actions の self-hosted runner 待機時間を検知し、20分以上待機しているジョブを検出・通知する仕組みを設計する。

## Goal

Create a practical design and implementation plan for detecting GitHub Actions workflow jobs that are waiting for self-hosted runners for 20 minutes or longer, then notifying operators.

## Initial scope

- Target: GitHub Actions jobs using self-hosted runners.
- Waiting threshold: 20 minutes by default.
- Notification target: configurable. Example: Slack, Teams, email, or GitHub Issue comment.
- Execution model: scheduled polling is acceptable for the first version.
- Cloud assumption: AWS-based implementation is acceptable.
- Preferred baseline architecture: EventBridge Scheduler + Lambda + GitHub API + notification destination.

## Out of scope for the first iteration

- Auto-scaling runner implementation itself.
- Automatic cancellation of waiting jobs.
- Full multi-tenant SaaS productization.
- Production deployment without human review.

## Expected outputs

- Design document.
- Implementation plan.
- Security considerations.
- Operational runbook.
- Review notes.
- Updated Memory Store.
