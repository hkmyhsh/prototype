# Project Rules

## Operational principles

- Prefer simple, observable mechanisms over opaque automation.
- Make detection thresholds configurable.
- Avoid noisy alerts by suppressing duplicates.
- Keep all secrets outside the repository.
- Any production rollout requires human approval.

## Documentation principles

- Every design must include failure handling.
- Every alert must have a runbook.
- Every non-trivial design choice must be recorded in `.agent/decisions.md`.
- Every task handoff must update `.agent/state.json`.

## Review principles

Reviewer mode should check:

- Does this reduce operational ambiguity?
- Can an operator understand the alert within five minutes?
- Are permissions minimal?
- Are failure modes visible?
- Can the implementation be safely tested before production use?
