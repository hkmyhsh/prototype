# Decisions

## D001: Repository-local Memory Store

Date: 2026-07-04

Decision: Use repository-local `.agent/` files as the first Memory Store implementation.

Reason: This keeps state reviewable in Git, works well with Codex, and avoids unnecessary database complexity in the first iteration.

## D002: Scheduled polling first

Date: 2026-07-04

Decision: Use scheduled polling as the first detection model.

Reason: GitHub Actions waiting-job detection can be implemented with a simple scheduled Lambda before introducing event-driven complexity.
