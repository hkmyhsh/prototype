# Review Notes

## Current review status

Initial scaffold created. Design and runbook are not yet complete.

## Open review items

- Confirm which GitHub API endpoint reliably exposes queued job timestamps for the target environment.
- Confirm whether organization-level or repository-level monitoring is required.
- Confirm notification destination.
- Confirm duplicate notification suppression strategy.
- Confirm GitHub App permission set.
