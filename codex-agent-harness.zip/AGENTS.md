# AGENTS.md

This repository uses Codex as an agentic engineering assistant for CI/CD operations improvement.

## Mission

Design, implement, validate, and document a mechanism that detects GitHub Actions jobs waiting for self-hosted runners for 20 minutes or longer, then notifies the appropriate channel.

## Working rules

Codex must treat `.agent/` as the Memory Store for this task.

At the start of every session:

1. Read `.agent/task.md`.
2. Read `.agent/state.json`.
3. Read `.agent/plan.md` if it exists.
4. Read `.agent/decisions.md`.
5. Identify the current step from `.agent/state.json`.

During work:

1. Update `.agent/state.json` whenever task status, current step, TODOs, blockers, or next action changes.
2. Append non-trivial technical decisions to `.agent/decisions.md`.
3. Record review findings in `.agent/review.md`.
4. Do not overwrite historical decisions. Append new entries instead.
5. Prefer small, reviewable changes.

At the end of every session:

1. Update `.agent/state.json`.
2. Set exactly one `next_action`.
3. Set `status` to one of:
   - `not_started`
   - `planning`
   - `in_progress`
   - `review_required`
   - `blocked`
   - `done`
4. If blocked, write a concrete `blocked_reason`.
5. If implementation changed, run or describe the validation steps.

## Agent roles

Codex should switch roles depending on the current phase.

### Planner mode

Use when the task is not decomposed yet or when the plan is stale.

Responsibilities:

- Understand the objective.
- Break the task into small steps.
- Clarify assumptions.
- Update `.agent/plan.md` and `.agent/state.json`.
- Avoid implementation unless the plan is accepted or clearly low-risk.

### Executor mode

Use when a concrete step is ready.

Responsibilities:

- Implement the current step.
- Keep changes minimal.
- Update `.agent/state.json` and `.agent/decisions.md`.
- Leave clear validation notes.

### Reviewer mode

Use after implementation or design changes.

Responsibilities:

- Review correctness, security, maintainability, and operability.
- Check whether the design satisfies the 20-minute waiting-job detection requirement.
- Record findings in `.agent/review.md`.
- Update `.agent/state.json` to either `done`, `review_required`, or `blocked`.

## Quality gates

Before marking work as done, verify:

- The design explains how to detect jobs waiting for self-hosted runners.
- The threshold is configurable and defaults to 20 minutes.
- Authentication and permissions are documented.
- Notification behavior is documented.
- Failure handling and retry behavior are documented.
- Audit logs or execution logs are considered.
- A runbook exists or is updated.
- Security risks are explicitly reviewed.

## Security rules

- Do not hard-code secrets.
- Prefer GitHub App authentication or OIDC-based access where applicable.
- Use least privilege permissions.
- Treat production notification and deployment endpoints as sensitive.
- Any destructive action requires human approval.

## Repository conventions

- Memory Store files live under `.agent/`.
- Design documents live under `docs/`.
- Keep Markdown files concise and structured.
- Prefer JSON for machine-readable state.
