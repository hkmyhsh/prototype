# Runbook: GitHub Actions Self-hosted Runner Waiting Job Alert

## Alert meaning

A GitHub Actions job has been waiting for a self-hosted runner for at least the configured threshold, initially 20 minutes.

## Initial triage

1. Open the workflow run URL in the alert.
2. Check the waiting job name and required labels.
3. Confirm whether matching self-hosted runners exist.
4. Check whether runners are online and idle.
5. Check whether the runner group allows the repository.
6. Check recent runner autoscaling or infrastructure errors.

## Common causes

- No runner has all required labels.
- Runner is offline.
- Runner group does not permit the repository.
- Runner capacity is exhausted.
- Autoscaler failed to provision new runners.
- Network or registration failure prevents new runners from appearing.
- Job label changed but runner labels were not updated.

## Immediate actions

### Label mismatch

- Compare job `runs-on` labels with runner labels.
- Fix workflow labels or runner labels.

### Capacity shortage

- Check current queued job count.
- Check autoscaler status.
- Scale runner capacity if approved.

### Runner offline

- Check runner host or pod health.
- Restart runner only if safe.
- Escalate if infrastructure is unhealthy.

### Runner group permission issue

- Confirm repository access to runner group.
- Request permission update if needed.

## Escalation

Escalate when:

- Multiple repositories are affected.
- Waiting time exceeds 60 minutes.
- Production release pipeline is blocked.
- Autoscaler or runner infrastructure is unhealthy.
- Permission changes are required.

## Recovery confirmation

Confirm that:

- The job starts running.
- New jobs are no longer queued unexpectedly.
- Runner capacity is stable.
- No duplicate alerts continue after recovery.

## Post-incident update

Record:

- Root cause.
- Affected repositories.
- Waiting duration.
- Corrective action.
- Whether detection threshold or runbook needs adjustment.
