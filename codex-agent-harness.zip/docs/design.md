# Design: GitHub Actions Self-hosted Runner Waiting Job Detection

## Problem

GitHub Actions jobs that require self-hosted runners can remain queued when there is not enough runner capacity, when labels do not match, or when runners are offline. Operators need to detect jobs waiting for 20 minutes or longer and notify the responsible team.

## Goal

Detect workflow jobs waiting for self-hosted runner capacity for at least 20 minutes and send a notification with enough context for initial triage.

## Baseline architecture

```text
EventBridge Scheduler
  -> Lambda
    -> GitHub API
    -> Waiting job detector
    -> Duplicate suppression store
    -> Notification destination
    -> CloudWatch Logs
```

## Components

### EventBridge Scheduler

Runs the detector on a fixed interval, for example every 5 minutes.

### Lambda

Executes the detection logic.

Responsibilities:

- Authenticate to GitHub.
- Collect recent workflow jobs.
- Filter jobs that are queued and require self-hosted runners.
- Calculate waiting duration.
- Send notification when duration exceeds threshold.
- Write execution logs.

### GitHub API client

Uses GitHub App authentication or another approved credential mechanism.

Required data:

- Repository.
- Workflow run ID.
- Job ID.
- Job name.
- Job labels.
- Job status.
- Created timestamp.
- Run URL or job URL.

### Duplicate suppression store

Prevents repeated notifications for the same waiting job.

Initial options:

- DynamoDB table keyed by `repository + job_id`.
- TTL-based expiration.
- Store last notification timestamp.

### Notification destination

Examples:

- Slack webhook.
- Microsoft Teams webhook.
- Email.
- GitHub Issue or Discussion.

The first version should keep notification destination configurable.

## Detection algorithm

1. Load configuration.
2. Authenticate to GitHub.
3. List target repositories or organization workflow runs.
4. Fetch jobs for recent workflow runs.
5. Filter jobs where:
   - status indicates queued or waiting state.
   - labels include self-hosted runner labels.
   - created timestamp is older than threshold.
6. Calculate waiting duration.
7. Check duplicate suppression store.
8. Send notification for new or re-alertable findings.
9. Store notification state.
10. Write structured logs.

## Configuration

Recommended configuration values:

```json
{
  "github_owner": "example-org",
  "repositories": ["repo-a", "repo-b"],
  "threshold_minutes": 20,
  "polling_interval_minutes": 5,
  "notification_destination": "slack",
  "duplicate_suppression_minutes": 60
}
```

## Notification content

Each notification should include:

- Repository.
- Workflow name if available.
- Workflow run ID.
- Job name.
- Job URL.
- Waiting duration.
- Required labels.
- Suggested first triage actions.

Example:

```text
GitHub Actions job has been waiting for a self-hosted runner for 24 minutes.
Repository: example-org/repo-a
Job: build-linux
Labels: self-hosted, linux, x64
Run: https://github.com/example-org/repo-a/actions/runs/123456789
Suggested action: check runner availability and label match.
```

## Security considerations

- Prefer GitHub App authentication.
- Grant only read access required for Actions metadata.
- Store GitHub private key or token in AWS Secrets Manager or Parameter Store.
- Do not store secrets in `.agent/` or source code.
- Restrict Lambda IAM permissions to required secrets, logs, and duplicate suppression table.
- Protect notification webhook URLs as secrets.
- Log metadata, not secret values.

## Observability

Lambda should emit structured logs:

- task execution ID.
- target owner/repository.
- number of runs scanned.
- number of jobs scanned.
- number of waiting jobs detected.
- number of notifications sent.
- API errors.
- notification errors.

Recommended metrics:

- `WaitingJobsDetected`.
- `NotificationsSent`.
- `GitHubApiErrors`.
- `DetectorExecutionFailed`.
- `DetectorDurationMs`.

## Failure handling

### GitHub API failure

- Retry transient errors with bounded retries.
- Log rate-limit and authentication errors clearly.
- Alert if detector fails repeatedly.

### Notification failure

- Retry transient failures.
- Log failed notification destination and job metadata.
- Do not mark notification as sent unless delivery succeeds.

### Duplicate store failure

- Fail closed or notify with caution depending on operational preference.
- Avoid notification storms.

## Open questions

- Exact target scope: organization-wide or repository list.
- Notification destination.
- GitHub API endpoint behavior for queued job timestamps in the actual environment.
- Whether runner group data is required.
- Whether detection should integrate with existing monitoring tools.
