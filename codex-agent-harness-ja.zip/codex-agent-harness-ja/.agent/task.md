# タスク定義

## テーマ

GitHub Actions の Self-hosted Runner 待機時間を検知し、20分以上待機しているジョブを検出・通知する仕組みを設計する。

## 背景

Self-hosted Runner を利用する CI/CD 基盤では、Runner の不足、Runner offline、ラベル不一致、ARC/EKS のスケール遅延などにより、Workflow Job が長時間待機することがある。

この状態を早期に検知し、運用担当者へ通知することで、ビルド遅延や利用者問い合わせの増加を防ぐ。

## 目的

20分以上 queued 状態の GitHub Actions Job を検知し、Slack などへ通知できる仕組みを設計・実装する。

## 想定成果物

- 方式設計
- Lambda または同等の定期実行処理
- GitHub API 呼び出し方式
- GitHub App 認証方式
- Slack 通知方式
- テスト観点
- Runbook
- 運用上の注意点

## 完了条件

以下を満たすこと。

- 20分以上待機しているジョブの検知方法が明確である
- GitHub App 認証の方針が明確である
- 通知条件と通知内容が定義されている
- 失敗時のログ確認方法が定義されている
- Runbook に初動対応が記載されている
- レビュー結果が `.agent/review.md` に記録されている
