# プロジェクト固有ルール

## 対象領域

このテンプレートは、CI/CD 基盤、GitHub Actions、Self-hosted Runner、AWS Lambda、運用監視、Runbook 整備を主な対象とする。

## 設計原則

- 最初は単純な構成を優先する
- 運用担当者が追跡できるログを残す
- 判断理由を必ず記録する
- 人間承認なしに本番変更をしない
- 秘密情報をリポジトリに保存しない
- 通知は多すぎても少なすぎてもいけない
- 検知、通知、調査、復旧の流れを分けて考える

## GitHub Actions 待機監視の観点

確認する主な原因:

- Self-hosted Runner 不足
- Runner offline
- Runner label 不一致
- ARC/EKS のスケール遅延
- Organization / Repository の権限不足
- GitHub API のRate Limit
- Workflow 側の concurrency 設定
- runner group 設定ミス

## AWS利用時の原則

- EventBridge Scheduler で定期実行する
- Lambda は短時間で終了する設計にする
- Secrets Manager または Parameter Store を利用する
- CloudWatch Logs に構造化ログを出す
- IAM 権限は最小化する

## ドキュメント方針

- 設計判断は `decisions.md` に残す
- 人間向け設計は `docs/design.md` に残す
- 障害対応は `docs/runbook.md` に残す
- Codex の再開情報は `state.json` に残す
