# 作業計画

## 現在の状態

初期状態。Planner mode で詳細計画を作成する。

## フェーズ

### Phase 1: 要件整理

- queued 状態の定義を確認する
- 20分以上待機の判定基準を定義する
- 対象リポジトリ、Organization、Enterprise の範囲を決める
- 通知先を決める

### Phase 2: 方式設計

- GitHub API で取得可能な情報を整理する
- EventBridge Scheduler + Lambda 構成を検討する
- GitHub App 認証方式を検討する
- Slack Webhook または Slack API 通知を検討する

### Phase 3: 実装

- ジョブ取得処理を作成する
- queued duration 判定を実装する
- 通知本文を作成する
- エラー処理を実装する
- ログ出力を整備する

### Phase 4: テスト

- queued job あり
- queued job なし
- API エラー
- 認証エラー
- Slack 通知失敗
- Runner offline 推定ケース

### Phase 5: レビュー・ドキュメント化

- 設計レビュー
- セキュリティレビュー
- 運用レビュー
- Runbook 更新
- 判断履歴更新

## 次の行動

Planner mode で、この計画を対象案件向けに具体化する。
